# Ayushi

## Module 1 - User Authentication & Authorization System

A Spring Boot application that provides secure user authentication and authorization using JWT (JSON Web Token), Spring Security, Role-Based Access Control (RBAC), and MySQL database integration.

---

## Project Overview

This project implements a secure authentication system where users can:

- Register an account
- Login securely
- Generate JWT tokens
- Access role-based features
- Logout securely
- Manage user information through MySQL database

The application follows a layered architecture using Spring Boot best practices.

---

## Technology Stack

| Technology | Version |
|------------|----------|
| Java | 17 |
| Spring Boot | 4.x |
| Spring Security | Latest |
| Spring Data JPA | Latest |
| JWT | 0.11.5 |
| MySQL | 8.x |
| Maven | Latest |
| Lombok | Latest |
| Eclipse IDE | 2026 |
| Postman | API Testing |

---

## Features Implemented

### Authentication

- User Registration
- User Login
- JWT Token Generation
- Password Encryption using BCrypt

### Authorization

- Spring Security Configuration
- Role-Based Access Control (RBAC)
- Permission Management

### Database

- User Data Storage
- JPA Repository Layer
- MySQL Integration

### Security

- JWT Authentication Filter
- Stateless Session Management
- Secure Password Storage

---

## Features Under Development

- Forgot Password
- Password Reset
- Email Notification Service
- Logout Token Blacklisting

---

## Project Structure

```text
src/main/java/com/Ayushi

├── Config
│   └── MailConfig.java
│
├── Controller
│   └── UserAuthController.java
│
├── DTO
│   ├── AuthResponseDTO.java
│   ├── EmailLogDTO.java
│   ├── LoginRequestDTO.java
│   └── RegisterRequestDTO.java
│
├── Entity
│   ├── EmailLog.java
│   └── UserAuth.java
│
├── Enum
│   ├── Permission.java
│   └── Role.java
│
├── Repository
│   ├── EmailLogRepository.java
│   └── UserAuthRepository.java
│
├── Security
│   ├── CustomUserDetailsService.java
│   ├── JWTAuthFilter.java
│   ├── JWTUtil.java
│   ├── RolePermissionConfig.java
│   ├── SecurityConfig.java
│   └── TokenBlockService.java
│
├── Services
│   ├── EmailLogService.java
│   └── UserAuthService.java
│
└── AyushiApplication.java
```

---

## API Endpoints

### Register User

**POST**

```http
/api/user_auth/register
```

Request Body:

```json
{
  "userName": "Sravan",
  "userOfficialEmail": "sravan@gmail.com",
  "password": "Password123",
  "role": "ADMIN"
}
```

Response:

```json
{
  "token": "jwt-token",
  "message": "user registered successfully"
}
```

---

### Login User

**POST**

```http
/api/user_auth/login
```

Request Body:

```json
{
  "userOfficialEmail": "sravan@gmail.com",
  "password": "Password123"
}
```

Response:

```text
Login successful
```

---

### Forgot Password

**POST**

```http
/api/user_auth/forgot_password?email=user@gmail.com
```

Status: Under Development

---

### Reset Password

**POST**

```http
/api/user_auth/reset_password
```

Status: Under Development

---

### Logout

**POST**

```http
/api/user_auth/logout
```

Status: Under Development

---

## Database Configuration

Database Used:

```text
MySQL
```

Main Table:

```text
user_auth
```

Stores:

- User ID
- Username
- Email
- Password
- Role
- Reset Token
- Token Expiry

---

## Security Features

### BCrypt Password Encoding

Passwords are encrypted before storing in the database.

### JWT Authentication

JWT tokens are generated after successful authentication.

### Stateless Session Management

No server-side sessions are maintained.

### Role-Based Access Control

Roles Supported:

- ADMIN
- USER

Permissions are managed through enums and role configuration.

---

## Screenshots

### Project Structure

_Add Screenshot Here_

File Name:

```text
screenshots/project-structure.png
```

---

### User Registration Success

_Add Screenshot Here_

File Name:

```text
screenshots/register-success.png
```

---

### User Login Success

_Add Screenshot Here_

File Name:

```text
screenshots/login-success.png
```

---

### Database Record

_Add Screenshot Here_

File Name:

```text
screenshots/database-record.png
```

---

## Future Enhancements

- Complete Forgot Password Flow
- Complete Reset Password Flow
- Email Notifications
- Refresh Token Support
- Swagger API Documentation
- Docker Deployment
- Unit Testing
- Integration Testing
  
---

## Project Status

Module 1 Completed Successfully

Current Version:

```text
v1.0
```

Planned Features:

- Forgot Password Completion
- Reset Password Completion
- Logout Completion
- Email Service Enhancement

---

## License

This project is created for learning, academic, and portfolio purposes.
